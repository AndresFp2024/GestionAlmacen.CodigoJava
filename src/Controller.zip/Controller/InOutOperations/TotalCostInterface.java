package Controller.InOutOperations;

public interface TotalCostInterface {

    double CalculatedCost();
    
}
