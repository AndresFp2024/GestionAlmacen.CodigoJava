package Controller;

import View.Warehouse.FrmStartWarehouse;


public class Main {  
    public static void main(String[] args) { 

        FrmStartWarehouse MainWindow = new FrmStartWarehouse();

        MainWindow.setVisible(true);

    }
}